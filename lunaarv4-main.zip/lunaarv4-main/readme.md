<div align=center>

<img align="center" src="public/media/logggo.svg" width="100">

<h1 align="center"> Lunaar v4</h1>

<h4 align="center">Lunaar is a new unblocked games site that has a proxy, loads of games, a sleek look, and much much more for you to see yourself!</h4>
<p>Ultraviolet based proxy.</p>

<h1 align="center"> Domains </h1>
<a href="https://discord.gg/k7jzF4jFpr" align="center"> The list of Domains can be found Here </a>

<h2> Deployment</h2>
<p> Lunaar is Dynamic you can deploy here</p>
<p>Requires NodeJS</p>

<p>

[![Run on Replit](https://binbashbanana.github.io/deploy-buttons/buttons/remade/replit.svg)](https://replit.com/github/Parcoil/lunaar.org)
[![Deploy to Vercel](https://binbashbanana.github.io/deploy-buttons/buttons/remade/vercel.svg)](https://vercel.com/new/clone?repository-url=https://github.com/Parcoil/lunaar.org)
<a target="_blank" href="https://railway.app/new/template?template=https://github.com/parcoil/lunaar.org"><img alt="Deploy on Railway" src="https://binbashbanana.github.io/deploy-buttons/buttons/remade/railway.svg"></a>
<a target="_blank" href="https://glitch.com/edit/#!/import/github/parcoil/lunaar.org"><img alt="Remix on Glitch" src="https://binbashbanana.github.io/deploy-buttons/buttons/remade/glitch.svg"></a>
[![Deploy to Koyeb](https://binbashbanana.github.io/deploy-buttons/buttons/remade/koyeb.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/Parcoil/lunaar.org&branch=main&name=Native)
[![Deploy to Render](https://binbashbanana.github.io/deploy-buttons/buttons/remade/render.svg)](https://render.com/deploy?repo=https://github.com/Parcoil/lunaar.org)
[![Deploy to Cyclic](https://binbashbanana.github.io/deploy-buttons/buttons/remade/cyclic.svg)](https://app.cyclic.sh/api/app/deploy/Parcoil/lunaar.org)

<h3 style="color: orange;">** Vercel Recomended **</h3>
</div>
<p>
<p>

 <h1> Manual Deploy</h1>
 
<h5> Clone the repo </h5>

```
$ git clone https://github.com/Parcoil/lunaar.org
```

<h5> Install </h5>

```
$ npm install
```

<h5> Start the server </h5>

```
$ npm start
```

<p>

<h1 align=center> Developers </h1>

- [@Thedogecraft](https://github.com/Thedogecraft)
- [@Noober](https://github.com/Hackerman2763)
- [@3kh0](https://github.com/3kh0)
- [@Ghostly](https://github.com/Ghostly6969)
